# WARNING
This repository is out of date.

# BigCloneBenchEval
This project has moved to [here]{https://github.com/jeffsvajlenko/BigCloneEval}.

# BigCloneBench
BigCloneBench is available [here]{https://github.com/clonebench/BigCloneBench/).

